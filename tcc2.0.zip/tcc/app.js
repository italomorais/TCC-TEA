const express = require('express');
const app = express();
const handlebars=require('express-handlebars')
const bodyparse = require('body-parser')
const post= require('./models/Post')

// config   
    // Termplate Engine
    app.engine('handlebars',handlebars({defaultLayout:'main'}))
    app.set('viwe engine','handlebars')
    //body parser
    app.use(bodyparse.urlencoded({extended:false}))
    app.use(bodyparse.json())

//rotaS 

app.get('/',function(req,res){
    post.findAll({order:[['id','DESC']]}).then(function(posts){
        res.render('home.handlebars',{posts:posts})

    })

 
})

app.get('/cad',function(req,res,){
    res.render('formulario.handlebars')
})

app.post('/add',function(req,res,){
 post.create({
     titulo:req.body.titulo,
     conteudo:req.body.conteudo

 }).then(function(){
     res.redirect('/')


 }).catch(function(){
    res.send("erro"+erro)

 })


})

app.get('/deletar/:id',function(req,rea){
    post.destroy({where: {'id':req.params.id}}).then(function(){
    res.send("sucesso")
    }).catch(function(erro){
        res.send("erro")

    })

})


app.listen(8082,function(){
    console.log("rodando ")
})

