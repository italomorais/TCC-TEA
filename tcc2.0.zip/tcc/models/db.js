const Sequelize = require('sequelize')

//conexao banco de dados
const sequelize = new Sequelize('Postapp','root','sasuke157',{
    host:"localhost",
    dialect:'mysql'
});
var db = {}; db.sequelize = sequelize; db.Sequelize = Sequelize; module.exports = db; 

 
