INSERT INTO  usuarios(nome,email,idade)VALUES(
 "Batman","italo@teste.com"
 8
);