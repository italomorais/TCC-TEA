HTML CSS JSResult
EDIT ON
$(document).ready(function(){
  $('#showPassword').on('click', function(){
    
    var passwordField = $('#senha');
    var passwordFieldType = passwordField.attr('type');
    if(passwordFieldType == 'senha')
    {
        passwordField.attr('type', 'text');
        $(this).val('Hide');
    } else {
        passwordField.attr('type', 'senha');
        $(this).val('Show');
    }
  });
});